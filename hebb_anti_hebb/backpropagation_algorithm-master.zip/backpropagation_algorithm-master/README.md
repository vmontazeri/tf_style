# Backpropagation algorithm 

### Abstract
Backtracking algorithm implementation using matlab by my own, without using toolboxs.

### Introduction

In this repo you will find a set of functions that allow you build a neural network, to regression or clasiffication problemas, using
the brack propagation algorithm and the sigmoid function as the activation function.

The structures and functions developed are all fully parametrized so you can desing your own neural network architecture, and implement other activation function and use it easily.

